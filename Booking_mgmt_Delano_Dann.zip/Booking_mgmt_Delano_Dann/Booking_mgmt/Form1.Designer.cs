﻿namespace Booking_mgmt
{
    partial class frontdesk_bookRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bookRoom_from = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.bookRoom_to = new System.Windows.Forms.DateTimePicker();
            this.bookRoom_clearBtn = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bookRoom_checkRoomBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bookRoom_imageView = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bookRoom_regPrice = new System.Windows.Forms.Label();
            this.bookRoom = new System.Windows.Forms.Label();
            this.bookRoom_total = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.bookRoom_status = new System.Windows.Forms.Label();
            this.bookRoom_roomName = new System.Windows.Forms.Label();
            this.bookRoom_roomType = new System.Windows.Forms.Label();
            this.bookRoom_roomID = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bookRoom_bookBtn = new System.Windows.Forms.Button();
            this.bookRoom_scheduleBtn = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bookRoom_imageView)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // bookRoom_from
            // 
            this.bookRoom_from.CalendarFont = new System.Drawing.Font("Times New Roman", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_from.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_from.Location = new System.Drawing.Point(139, 190);
            this.bookRoom_from.Name = "bookRoom_from";
            this.bookRoom_from.Size = new System.Drawing.Size(245, 25);
            this.bookRoom_from.TabIndex = 0;
            this.bookRoom_from.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Location = new System.Drawing.Point(54, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Check in :";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(295, 352);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 16);
            this.label3.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Control;
            this.label1.Location = new System.Drawing.Point(51, 243);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(72, 16);
            this.label1.TabIndex = 6;
            this.label1.Text = "Check out :";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // bookRoom_to
            // 
            this.bookRoom_to.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_to.Location = new System.Drawing.Point(139, 234);
            this.bookRoom_to.Name = "bookRoom_to";
            this.bookRoom_to.Size = new System.Drawing.Size(241, 25);
            this.bookRoom_to.TabIndex = 7;
            // 
            // bookRoom_clearBtn
            // 
            this.bookRoom_clearBtn.BackColor = System.Drawing.Color.DarkViolet;
            this.bookRoom_clearBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bookRoom_clearBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookRoom_clearBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_clearBtn.Location = new System.Drawing.Point(181, 460);
            this.bookRoom_clearBtn.Name = "bookRoom_clearBtn";
            this.bookRoom_clearBtn.Size = new System.Drawing.Size(123, 32);
            this.bookRoom_clearBtn.TabIndex = 10;
            this.bookRoom_clearBtn.Text = "Clear";
            this.bookRoom_clearBtn.UseVisualStyleBackColor = false;
            this.bookRoom_clearBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Lavender;
            this.panel1.Controls.Add(this.bookRoom_checkRoomBtn);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(563, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(589, 271);
            this.panel1.TabIndex = 14;
            // 
            // bookRoom_checkRoomBtn
            // 
            this.bookRoom_checkRoomBtn.BackColor = System.Drawing.Color.DarkViolet;
            this.bookRoom_checkRoomBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bookRoom_checkRoomBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookRoom_checkRoomBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_checkRoomBtn.ForeColor = System.Drawing.SystemColors.InactiveBorder;
            this.bookRoom_checkRoomBtn.Location = new System.Drawing.Point(18, 220);
            this.bookRoom_checkRoomBtn.Name = "bookRoom_checkRoomBtn";
            this.bookRoom_checkRoomBtn.Size = new System.Drawing.Size(124, 39);
            this.bookRoom_checkRoomBtn.TabIndex = 17;
            this.bookRoom_checkRoomBtn.Text = "Check Room";
            this.bookRoom_checkRoomBtn.UseVisualStyleBackColor = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 37);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(553, 178);
            this.dataGridView1.TabIndex = 2;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 10);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "Available Rooms";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Lavender;
            this.panel2.Controls.Add(this.bookRoom_imageView);
            this.panel2.Location = new System.Drawing.Point(563, 289);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(589, 238);
            this.panel2.TabIndex = 15;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // bookRoom_imageView
            // 
            this.bookRoom_imageView.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.bookRoom_imageView.Location = new System.Drawing.Point(16, 27);
            this.bookRoom_imageView.Name = "bookRoom_imageView";
            this.bookRoom_imageView.Size = new System.Drawing.Size(553, 188);
            this.bookRoom_imageView.TabIndex = 0;
            this.bookRoom_imageView.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Lavender;
            this.panel3.Controls.Add(this.bookRoom_regPrice);
            this.panel3.Controls.Add(this.bookRoom);
            this.panel3.Controls.Add(this.bookRoom_total);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.bookRoom_status);
            this.panel3.Controls.Add(this.bookRoom_roomName);
            this.panel3.Controls.Add(this.bookRoom_roomType);
            this.panel3.Controls.Add(this.bookRoom_roomID);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.bookRoom_bookBtn);
            this.panel3.Controls.Add(this.bookRoom_scheduleBtn);
            this.panel3.Controls.Add(this.bookRoom_to);
            this.panel3.Controls.Add(this.bookRoom_from);
            this.panel3.Controls.Add(this.bookRoom_clearBtn);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Location = new System.Drawing.Point(12, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(520, 515);
            this.panel3.TabIndex = 16;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // bookRoom_regPrice
            // 
            this.bookRoom_regPrice.AutoSize = true;
            this.bookRoom_regPrice.Location = new System.Drawing.Point(136, 154);
            this.bookRoom_regPrice.Name = "bookRoom_regPrice";
            this.bookRoom_regPrice.Size = new System.Drawing.Size(31, 16);
            this.bookRoom_regPrice.TabIndex = 29;
            this.bookRoom_regPrice.Text = "0.00";
            // 
            // bookRoom
            // 
            this.bookRoom.AutoSize = true;
            this.bookRoom.Location = new System.Drawing.Point(32, 154);
            this.bookRoom.Name = "bookRoom";
            this.bookRoom.Size = new System.Drawing.Size(91, 16);
            this.bookRoom.TabIndex = 27;
            this.bookRoom.Text = "Base Price($):";
            this.bookRoom.Click += new System.EventHandler(this.label4_Click);
            // 
            // bookRoom_total
            // 
            this.bookRoom_total.AutoSize = true;
            this.bookRoom_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_total.Location = new System.Drawing.Point(289, 336);
            this.bookRoom_total.Name = "bookRoom_total";
            this.bookRoom_total.Size = new System.Drawing.Size(40, 20);
            this.bookRoom_total.TabIndex = 26;
            this.bookRoom_total.Text = "0.00";
            this.bookRoom_total.Click += new System.EventHandler(this.bookRoom_total_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(162, 336);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(121, 20);
            this.label13.TabIndex = 25;
            this.label13.Text = "Total Price ($):";
            // 
            // bookRoom_status
            // 
            this.bookRoom_status.AutoSize = true;
            this.bookRoom_status.Location = new System.Drawing.Point(136, 121);
            this.bookRoom_status.Name = "bookRoom_status";
            this.bookRoom_status.Size = new System.Drawing.Size(62, 16);
            this.bookRoom_status.TabIndex = 24;
            this.bookRoom_status.Text = "***********";
            // 
            // bookRoom_roomName
            // 
            this.bookRoom_roomName.AutoSize = true;
            this.bookRoom_roomName.Location = new System.Drawing.Point(136, 90);
            this.bookRoom_roomName.Name = "bookRoom_roomName";
            this.bookRoom_roomName.Size = new System.Drawing.Size(62, 16);
            this.bookRoom_roomName.TabIndex = 23;
            this.bookRoom_roomName.Text = "***********";
            // 
            // bookRoom_roomType
            // 
            this.bookRoom_roomType.AutoSize = true;
            this.bookRoom_roomType.Location = new System.Drawing.Point(136, 55);
            this.bookRoom_roomType.Name = "bookRoom_roomType";
            this.bookRoom_roomType.Size = new System.Drawing.Size(62, 16);
            this.bookRoom_roomType.TabIndex = 22;
            this.bookRoom_roomType.Text = "***********";
            // 
            // bookRoom_roomID
            // 
            this.bookRoom_roomID.AutoSize = true;
            this.bookRoom_roomID.Location = new System.Drawing.Point(136, 25);
            this.bookRoom_roomID.Name = "bookRoom_roomID";
            this.bookRoom_roomID.Size = new System.Drawing.Size(62, 16);
            this.bookRoom_roomID.TabIndex = 21;
            this.bookRoom_roomID.Text = "***********";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(78, 121);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 16);
            this.label9.TabIndex = 20;
            this.label9.Text = "Status";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 55);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 16);
            this.label8.TabIndex = 19;
            this.label8.Text = "Room Type";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 90);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(84, 16);
            this.label7.TabIndex = 18;
            this.label7.Text = "Room Name";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(62, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 16);
            this.label6.TabIndex = 17;
            this.label6.Text = "Room ID";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // bookRoom_bookBtn
            // 
            this.bookRoom_bookBtn.BackColor = System.Drawing.Color.DarkViolet;
            this.bookRoom_bookBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bookRoom_bookBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookRoom_bookBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_bookBtn.Location = new System.Drawing.Point(181, 375);
            this.bookRoom_bookBtn.Name = "bookRoom_bookBtn";
            this.bookRoom_bookBtn.Size = new System.Drawing.Size(123, 41);
            this.bookRoom_bookBtn.TabIndex = 16;
            this.bookRoom_bookBtn.Text = "Book";
            this.bookRoom_bookBtn.UseVisualStyleBackColor = false;
            this.bookRoom_bookBtn.Click += new System.EventHandler(this.button7_Click);
            // 
            // bookRoom_scheduleBtn
            // 
            this.bookRoom_scheduleBtn.BackColor = System.Drawing.Color.DarkViolet;
            this.bookRoom_scheduleBtn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.bookRoom_scheduleBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bookRoom_scheduleBtn.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bookRoom_scheduleBtn.Location = new System.Drawing.Point(166, 277);
            this.bookRoom_scheduleBtn.Name = "bookRoom_scheduleBtn";
            this.bookRoom_scheduleBtn.Size = new System.Drawing.Size(153, 32);
            this.bookRoom_scheduleBtn.TabIndex = 14;
            this.bookRoom_scheduleBtn.Text = "Schedule Now";
            this.bookRoom_scheduleBtn.UseVisualStyleBackColor = false;
            this.bookRoom_scheduleBtn.Click += new System.EventHandler(this.bookRoom_scheduleBtn_Click);
            // 
            // frontdesk_bookRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumPurple;
            this.ClientSize = new System.Drawing.Size(1197, 552);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Name = "frontdesk_bookRoom";
            this.Text = "Booking Management";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bookRoom_imageView)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker bookRoom_from;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker bookRoom_to;
        private System.Windows.Forms.Button bookRoom_clearBtn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button bookRoom_bookBtn;
        private System.Windows.Forms.Button bookRoom_scheduleBtn;
        private System.Windows.Forms.Button bookRoom_checkRoomBtn;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label bookRoom_status;
        private System.Windows.Forms.Label bookRoom_roomName;
        private System.Windows.Forms.Label bookRoom_roomType;
        private System.Windows.Forms.Label bookRoom_roomID;
        private System.Windows.Forms.Label bookRoom_total;
        private System.Windows.Forms.PictureBox bookRoom_imageView;
        private System.Windows.Forms.Label bookRoom_regPrice;
        private System.Windows.Forms.Label bookRoom;
    }
}

