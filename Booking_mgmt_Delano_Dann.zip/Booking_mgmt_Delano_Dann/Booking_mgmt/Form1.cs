﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Booking_mgmt
{
    public partial class frontdesk_bookRoom : Form
    {
        public frontdesk_bookRoom()
        {
            InitializeComponent();
            displayRooms();
        }

        public void displayRooms()
        {
            roomsData rData = new roomsData();
            List<roomsData> listData = rData.roomsDataList();
            dataGridView1.DataSource = listData;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form formbg = new Form();
            try 
            {
                using (clientInfo ciForm = new clientInfo())
                {
                    formbg.StartPosition = FormStartPosition.CenterParent;
                    formbg.FormBorderStyle = FormBorderStyle.None;
                    formbg.Opacity = 0.08d;
                    formbg.BackColor = Color.Black;
                    formbg.TopMost = true;
                    formbg.WindowState = FormWindowState.Normal;
                    formbg.Location = this.Location;
                    formbg.ShowInTaskbar = false;
                    formbg.Show();

                    ciForm.Owner = formbg;
                    ciForm.ShowDialog();

                   
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error:" + ex, "Error Message", MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally 
            {
            formbg.Dispose();
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private int getID =0;

        private decimal regprice = 0;

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                getID = (int)row.Cells[0].Value;
                bookRoom_roomID.Text = row.Cells[1].Value.ToString();
                bookRoom_roomType.Text = row.Cells[2].Value.ToString();
                bookRoom_roomName.Text = row.Cells[3].Value.ToString();
                bookRoom_regPrice.Text = (Convert.ToInt32(row.Cells[4].Value).ToString("0.00"));


                regprice = Convert.ToDecimal(row.Cells[4].Value);

                bookRoom_imageView.ImageLocation = row.Cells[6].Value.ToString();

                bookRoom_status.Text = row.Cells[5].Value.ToString();
            }
        }

        private void employee_bookRoom1_Load(object sender, EventArgs e)
        {

        }

        private void bookRoom_scheduleBtn_Click(object sender, EventArgs e)
        {
            DateTime fromDate = bookRoom_from.Value;
            DateTime toDate = bookRoom_to.Value;

            TimeSpan countDays = toDate - fromDate;

            int days = countDays.Days;

            decimal totalPrice = (days * regprice);

            if(totalPrice < 0)
            {
                MessageBox.Show("Please select a valid date range.");

                bookRoom_total.Text = "0.00";
            }
            else if(totalPrice == 0)               
            {
                bookRoom_total.Text = regprice.ToString("0.00");
            }
            else
            {
                bookRoom_total.Text = (days * regprice).ToString("0.00");

            }
        }

        private void bookRoom_total_Click(object sender, EventArgs e)
        {
             
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
