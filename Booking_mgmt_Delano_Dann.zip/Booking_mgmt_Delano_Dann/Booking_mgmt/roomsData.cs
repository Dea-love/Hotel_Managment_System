﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient; 
using System.Data;



namespace Booking_mgmt
{
    class roomsData
    {
        private string conn = @"Data Source=DDANN-LPT\SQLEXPRESS;Initial Catalog=BookingMgmt;Integrated Security=True;TrustServerCertificate=True";

        public int ID { get; set; } //0

        public string RoomID { get; set; }//1
        public string RoomName { get; set; }//2

        public string RoomType { get; set; }//3
        public string Cost { get; set; }//4
        public string Status { get; set; }//5
        public string Image { get; set; }//6
        public string Date { get; set; }//7

        public List<roomsData> roomsDataList()
        {
            List<roomsData> listdata = new List<roomsData>();
            using (SqlConnection connect = new SqlConnection(conn))
            {
                connect.Open();

                string selectData = "SELECT * FROM hRooms where date_delete IS NULL";
                using (SqlCommand cmd = new SqlCommand(selectData, connect))
                {
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        roomsData rData = new roomsData();

                        rData.ID = (int)reader["id"];
                        rData.RoomName = reader["room_name"].ToString();
                        rData.RoomType = reader["type"].ToString();
                        rData.Cost = reader["cost"].ToString(); 
                        rData.Status = reader["status"].ToString();
                        rData.Image = reader["image_path"].ToString();
                        rData.Date = reader["date_register"].ToString();
                        rData.RoomID = reader["room_id"].ToString();

                        listdata.Add(rData);
                    }
                }
            }
            return listdata;
        }
    }
        
    
}   
