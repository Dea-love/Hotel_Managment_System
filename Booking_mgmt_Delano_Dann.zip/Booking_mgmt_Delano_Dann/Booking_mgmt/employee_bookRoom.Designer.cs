﻿namespace Booking_mgmt
{
    partial class admin_bookRoom
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rooms_clearbtn = new System.Windows.Forms.Button();
            this.rooms_deletebtn = new System.Windows.Forms.Button();
            this.rooms_updatebtn = new System.Windows.Forms.Button();
            this.rooms_addbtn = new System.Windows.Forms.Button();
            this.rooms_importbtn = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.rooms_picture = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.rooms_status = new System.Windows.Forms.ComboBox();
            this.rooms_type = new System.Windows.Forms.ComboBox();
            this.rooms_roomCost = new System.Windows.Forms.TextBox();
            this.rooms_roomName = new System.Windows.Forms.TextBox();
            this.rooms_roomID = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rooms_picture)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dataGridView1);
            this.panel1.Location = new System.Drawing.Point(19, 21);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1103, 332);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(180, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Room Information";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(13, 46);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1074, 268);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rooms_clearbtn);
            this.panel2.Controls.Add(this.rooms_deletebtn);
            this.panel2.Controls.Add(this.rooms_updatebtn);
            this.panel2.Controls.Add(this.rooms_addbtn);
            this.panel2.Controls.Add(this.rooms_importbtn);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.rooms_status);
            this.panel2.Controls.Add(this.rooms_type);
            this.panel2.Controls.Add(this.rooms_roomCost);
            this.panel2.Controls.Add(this.rooms_roomName);
            this.panel2.Controls.Add(this.rooms_roomID);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(19, 377);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1103, 224);
            this.panel2.TabIndex = 1;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // rooms_clearbtn
            // 
            this.rooms_clearbtn.Location = new System.Drawing.Point(503, 178);
            this.rooms_clearbtn.Name = "rooms_clearbtn";
            this.rooms_clearbtn.Size = new System.Drawing.Size(127, 33);
            this.rooms_clearbtn.TabIndex = 15;
            this.rooms_clearbtn.Text = "Clear";
            this.rooms_clearbtn.UseVisualStyleBackColor = true;
            this.rooms_clearbtn.Click += new System.EventHandler(this.rooms_clearbtn_Click);
            // 
            // rooms_deletebtn
            // 
            this.rooms_deletebtn.Location = new System.Drawing.Point(350, 178);
            this.rooms_deletebtn.Name = "rooms_deletebtn";
            this.rooms_deletebtn.Size = new System.Drawing.Size(127, 33);
            this.rooms_deletebtn.TabIndex = 14;
            this.rooms_deletebtn.Text = "Delete";
            this.rooms_deletebtn.UseVisualStyleBackColor = true;
            this.rooms_deletebtn.Click += new System.EventHandler(this.rooms_deletebtn_Click);
            // 
            // rooms_updatebtn
            // 
            this.rooms_updatebtn.Location = new System.Drawing.Point(210, 178);
            this.rooms_updatebtn.Name = "rooms_updatebtn";
            this.rooms_updatebtn.Size = new System.Drawing.Size(127, 33);
            this.rooms_updatebtn.TabIndex = 13;
            this.rooms_updatebtn.Text = "Update";
            this.rooms_updatebtn.UseVisualStyleBackColor = true;
            this.rooms_updatebtn.Click += new System.EventHandler(this.rooms_updatebtn_Click);
            // 
            // rooms_addbtn
            // 
            this.rooms_addbtn.Location = new System.Drawing.Point(57, 178);
            this.rooms_addbtn.Name = "rooms_addbtn";
            this.rooms_addbtn.Size = new System.Drawing.Size(127, 33);
            this.rooms_addbtn.TabIndex = 12;
            this.rooms_addbtn.Text = "Add";
            this.rooms_addbtn.UseVisualStyleBackColor = true;
            this.rooms_addbtn.Click += new System.EventHandler(this.rooms_addbtn_Click);
            // 
            // rooms_importbtn
            // 
            this.rooms_importbtn.Location = new System.Drawing.Point(797, 178);
            this.rooms_importbtn.Name = "rooms_importbtn";
            this.rooms_importbtn.Size = new System.Drawing.Size(127, 33);
            this.rooms_importbtn.TabIndex = 11;
            this.rooms_importbtn.Text = "IMPORT";
            this.rooms_importbtn.UseVisualStyleBackColor = true;
            this.rooms_importbtn.Click += new System.EventHandler(this.rooms_importbtn_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.rooms_picture);
            this.panel3.Controls.Add(this.pictureBox1);
            this.panel3.Location = new System.Drawing.Point(797, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(127, 143);
            this.panel3.TabIndex = 10;
            // 
            // rooms_picture
            // 
            this.rooms_picture.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.rooms_picture.Location = new System.Drawing.Point(0, 0);
            this.rooms_picture.Name = "rooms_picture";
            this.rooms_picture.Size = new System.Drawing.Size(127, 143);
            this.rooms_picture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.rooms_picture.TabIndex = 1;
            this.rooms_picture.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(50, 61);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // rooms_status
            // 
            this.rooms_status.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms_status.FormattingEnabled = true;
            this.rooms_status.Items.AddRange(new object[] {
            "Occupied",
            "Vacancy"});
            this.rooms_status.Location = new System.Drawing.Point(496, 74);
            this.rooms_status.Name = "rooms_status";
            this.rooms_status.Size = new System.Drawing.Size(121, 30);
            this.rooms_status.TabIndex = 9;
            // 
            // rooms_type
            // 
            this.rooms_type.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms_type.FormattingEnabled = true;
            this.rooms_type.Items.AddRange(new object[] {
            "Single Bedroom",
            "Double Bedroom"});
            this.rooms_type.Location = new System.Drawing.Point(163, 88);
            this.rooms_type.Name = "rooms_type";
            this.rooms_type.Size = new System.Drawing.Size(193, 30);
            this.rooms_type.TabIndex = 8;
            // 
            // rooms_roomCost
            // 
            this.rooms_roomCost.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms_roomCost.Location = new System.Drawing.Point(496, 33);
            this.rooms_roomCost.Name = "rooms_roomCost";
            this.rooms_roomCost.Size = new System.Drawing.Size(152, 28);
            this.rooms_roomCost.TabIndex = 7;
            // 
            // rooms_roomName
            // 
            this.rooms_roomName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms_roomName.Location = new System.Drawing.Point(163, 131);
            this.rooms_roomName.Name = "rooms_roomName";
            this.rooms_roomName.Size = new System.Drawing.Size(152, 28);
            this.rooms_roomName.TabIndex = 6;
            // 
            // rooms_roomID
            // 
            this.rooms_roomID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rooms_roomID.Location = new System.Drawing.Point(163, 33);
            this.rooms_roomID.Name = "rooms_roomID";
            this.rooms_roomID.Size = new System.Drawing.Size(152, 28);
            this.rooms_roomID.TabIndex = 5;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(411, 77);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(66, 22);
            this.label6.TabIndex = 4;
            this.label6.Text = "Status:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(411, 33);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 22);
            this.label5.TabIndex = 3;
            this.label5.Text = "Cost ($):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(43, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 22);
            this.label4.TabIndex = 2;
            this.label4.Text = "Room Name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(101, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 22);
            this.label3.TabIndex = 1;
            this.label3.Text = "Type:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(73, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(84, 22);
            this.label2.TabIndex = 0;
            this.label2.Text = "Room ID:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // admin_bookRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "admin_bookRoom";
            this.Size = new System.Drawing.Size(1144, 617);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.rooms_picture)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox rooms_status;
        private System.Windows.Forms.ComboBox rooms_type;
        private System.Windows.Forms.TextBox rooms_roomCost;
        private System.Windows.Forms.TextBox rooms_roomName;
        private System.Windows.Forms.TextBox rooms_roomID;
        private System.Windows.Forms.Button rooms_importbtn;
        private System.Windows.Forms.PictureBox rooms_picture;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button rooms_updatebtn;
        private System.Windows.Forms.Button rooms_addbtn;
        private System.Windows.Forms.Button rooms_clearbtn;
        private System.Windows.Forms.Button rooms_deletebtn;
    }
}
